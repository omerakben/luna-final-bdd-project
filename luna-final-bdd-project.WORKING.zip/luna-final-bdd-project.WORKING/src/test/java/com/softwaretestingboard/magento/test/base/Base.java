package com.softwaretestingboard.magento.test.base;

public class Base {
    public static void main(String[] args) {
        System.out.println("Katia's Change!");
    }
}
